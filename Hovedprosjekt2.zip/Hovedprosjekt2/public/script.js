let h1 = document.getElementById("h1");
let newBtn = document.getElementById("newBtn");
let enBtn = document.getElementById("enBtn");
let noBtn = document.getElementById("noBtn");
let ChosenLanguage = document.getElementById("ChosenLanguage");
let language = "En";
let index = -1;
let elmDick;

(async function () {
  serverResponse("En");
})();

newBtn.addEventListener("click", () => {
  index = -1;
  serverResponse(language);
});

enBtn.addEventListener("click", async () => {
  await serverResponse("En");
  language = "En";
  elementLanguage();
});

noBtn.addEventListener("click", async () => {
  await serverResponse("No");
  language = "No";
  elementLanguage();
});

async function serverResponse(lang) {
  let data = await fetch(`/getJoke${lang}/${index}`);
  let joke = await data.json();
  h1.innerHTML = joke.joke[0];
  index = joke.joke[1];
  elmDick = joke.elements;
}

function elementLanguage() {
  let elm = document.querySelectorAll("body > *");

  for (const el of elm) {
    let id = el.id;
    for (const [key, value] of Object.entries(elmDick)) {
      if (key === id) {
        el.innerHTML = value;
      }
    }
  }
}
